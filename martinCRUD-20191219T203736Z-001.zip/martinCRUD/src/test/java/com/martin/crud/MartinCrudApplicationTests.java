package com.martin.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MartinCrudApplicationTests {

	@Test
	void contextLoads() {
	}


}
